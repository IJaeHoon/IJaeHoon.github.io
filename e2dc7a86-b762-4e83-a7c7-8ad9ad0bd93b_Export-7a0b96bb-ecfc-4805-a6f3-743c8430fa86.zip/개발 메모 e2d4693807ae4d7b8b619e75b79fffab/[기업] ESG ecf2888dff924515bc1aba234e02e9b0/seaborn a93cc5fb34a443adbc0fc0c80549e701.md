# seaborn

[https://seaborn.pydata.org/examples/wide_data_lineplot.html](https://seaborn.pydata.org/examples/wide_data_lineplot.html)

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import statsmodels as sm

[한글폰트깨짐]

from matplotlib import font_manager, rc

font_name = font_manager.FontProperties(fname="c:/Windows/Fonts/malgun.ttf").get_name()
rc('font', family=font_name)

[https://www.shutterstock.com/ko/search/신호등로고?cr=bc&ds_ag=FF%3Dicon|logo_AU%3DProspecting&ds_agid=58700008495748772&ds_cid=71700000112944605&ds_eid=700000001520946&gclid=CjwKCAjw5_GmBhBIEiwA5QSMxGwFM7rL3Oz1TDpku5Vqrw4CkUp_e6k5E3Jwca0ywHaL3vjUfW9TMhoCrwgQAvD_BwE&gclsrc=aw.ds&kw=무료 로고&pl=PPC_GOO_KR_IG_VAR-667716916253&utm_campaign=CO%3DKR_LG%3DKO_BU%3DIMG_AD%3DGENERIC_TS%3Dlggeneric_RG%3DAPAC_AB%3DACQ_CH%3DSEM_OG%3DCONV_PB%3DGoogle_FF%3DKO BM-VAR&utm_medium=cpc&utm_source=GOOGLE](https://www.shutterstock.com/ko/search/%ec%8b%a0%ed%98%b8%eb%93%b1%eb%a1%9c%ea%b3%a0?cr=bc&ds_ag=FF%3Dicon%7Clogo_AU%3DProspecting&ds_agid=58700008495748772&ds_cid=71700000112944605&ds_eid=700000001520946&gclid=CjwKCAjw5_GmBhBIEiwA5QSMxGwFM7rL3Oz1TDpku5Vqrw4CkUp_e6k5E3Jwca0ywHaL3vjUfW9TMhoCrwgQAvD_BwE&gclsrc=aw.ds&kw=%EB%AC%B4%EB%A3%8C%20%EB%A1%9C%EA%B3%A0&pl=PPC_GOO_KR_IG_VAR-667716916253&utm_campaign=CO%3DKR_LG%3DKO_BU%3DIMG_AD%3DGENERIC_TS%3Dlggeneric_RG%3DAPAC_AB%3DACQ_CH%3DSEM_OG%3DCONV_PB%3DGoogle_FF%3DKO%20BM-VAR&utm_medium=cpc&utm_source=GOOGLE)

ai 허브 경찰청

★‘esg’라는 지표를 기업에선 많이 평가한다

프로젝트에 필요한 분석, 시장가치, 향후 발전가능성 → 우수성

![Untitled](Untitled.png)

IR

[개발]

무얼할까  → 정확하게

 - 몇개를 어떻게 할까

-해시스크래프

기업 등에서 올거고 채용도 고려할 것

(측량되지않은데이터 대체데이터)

빅데이터 다음 단계 → 예측분석시장

다음 월화수 머신러닝 기초 / 진행예정

★ 사고가 가장 많이 발생하는 위치 시각화

★사고다발 위치